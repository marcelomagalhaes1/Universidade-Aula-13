package br.marcelo.universidade;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UniversidadeApplicationTests {

	@Test
	void contextLoads() {
	}

}
